#pragma once
class Road
{
public:
	Road();
	~Road();
};

