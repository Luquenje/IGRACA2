#include "stdafx.h"
#include "Road.h"


Road::Road()
{
}


Road::~Road()
{
}
